# 笔记
## 关于
* 简介：静态网页形式的笔记本
* 代码：已经放在我的[GitHub](https://github.com/SqRoots/biji)上了


## 说明
* 本程序还存在一些问题，正在修改中。
* 很多笔记正在整理中，之后可能会分建多个笔记本。
* 欢迎将您的宝贵建议发到我的邮箱：lixuan150@gmail.com


## 致谢

非常感谢下列程序和服务

* [Pandoc](http://pandoc.org)
* [MathJax](https://www.mathjax.org/)
* [HighlightJS（目前使用此代码高亮程序，以后可能会使用GoogleCodePrettify，各有所长，正在犹豫）](https://highlightjs.org/)
* [GoogleCodePrettify](https://code.google.com/archive/p/google-code-prettify/)

**再次向开源程序工作者和免费服务致谢！**
