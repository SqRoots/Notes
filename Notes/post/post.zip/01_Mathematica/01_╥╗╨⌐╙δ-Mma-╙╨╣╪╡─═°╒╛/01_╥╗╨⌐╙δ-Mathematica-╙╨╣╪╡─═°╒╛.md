# 官方网站
* [官网](http://www.wolfram.com/)
* [帮助](http://reference.wolfram.com/language/?source=nav)
* [社区](http://community.wolfram.com/)
* [学习中心](http://www.wolfram.com/support/learn/)
* [官方教程下载](http://www.wolfram.com/learningcenter/tutorialcollection/)
* [Wolfram Alpha](http://www.wolframalpha.com/)
* [Mathematica 版本更新历史](http://www.wolfram.com/mathematica/quick-revision-history.html)
* [Math World（数学世界，维基百科中查不到的数学词条可以在这里试试）](http://mathworld.wolfram.com/)

# 社区
* [官方社区](http://community.wolfram.com/)
* [Stack Exchange](http://mathematica.stackexchange.com/)
* [百度贴吧](http://tieba.baidu.com/f?kw=mathematica&fr=index)
* [新科学](http://www.newsciencecore.com)
* []()

# 博客
* [闲云谷](http://xianyungu.com)
* []()

# 其它
* [Wolfram CodeCards](http://wolfram.com/codecards)官方作的宣传纸牌，案例不但精简而且很漂亮！