# StackExchange 中的 Mathematica 问题集

## 图像处理
* [自动去水印](http://mathematica.stackexchange.com/questions/95512/how-to-automatically-remove-text-from-images/96583#96583)